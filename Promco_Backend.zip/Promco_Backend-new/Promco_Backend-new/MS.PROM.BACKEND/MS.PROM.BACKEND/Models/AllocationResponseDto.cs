﻿namespace MS.PROM.BACKEND.Models
{
    public class AllocationResponseDto
    {


    //private long totalElements;
    //private int totalPages;
    //private List<TbPfcAllocation> allocationItems;

    //public AllocationResponseDto()
    //{
    //}

    //public long TotalElements
    //{
    //    get { return totalElements; }
    //    set { totalElements = value; }
    //}

    //public int TotalPages
    //{
    //    get { return totalPages; }
    //    set { totalPages = value; }
    //}

    //public List<TbPfcAllocation> AllocationItems
    //{
    //    get { return allocationItems; }
    //    set { allocationItems = value; }
    //}
}




    }

