﻿using System;
using System.Collections.Generic;

namespace MS.PROM.BACKEND.MidasDTO
{
    public partial class Designation
    {
        public string DsgCode { get; set; } = null!;
        public string? DsgName { get; set; }
    }
}
