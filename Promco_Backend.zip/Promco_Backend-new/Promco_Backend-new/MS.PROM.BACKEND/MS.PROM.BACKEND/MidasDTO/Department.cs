﻿using System;
using System.Collections.Generic;

namespace MS.PROM.BACKEND.MidasDTO
{
    public partial class Department
    {
        public int RnDepId { get; set; }
        public string? DeptName { get; set; }
    }
}
