import axios from 'axios';

const API_URL = 'https://localhost:7207'; // Replace with your ASP.NET Core API URL

// Function to handle user signup
export const signup = async (userDto) => {
  try {
    const response = await axios.post(`${API_URL}/api/auth/signup`, userDto);
    return response.data;
  } catch (error) {
    console.error('Error during signup:', error);
    throw error;
  }
};

// Function to handle user login
export const login = async (userDto) => {
  try {
    const response = await axios.post(`${API_URL}/api/auth/login`, userDto);
    return response.data;
  } catch (error) {
    console.error('Error during login:', error);
    throw error;
  }
};
