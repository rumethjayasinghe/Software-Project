import React, { useState, useEffect } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  
  const navigate = useNavigate(); // Hook to navigate to another route

  // On page load, check if credentials are stored in localStorage
  useEffect(() => {
    const storedEmail = localStorage.getItem('email');
    const storedPassword = localStorage.getItem('password');
    
    if (storedEmail && storedPassword) {
      setFormData({
        email: storedEmail,
        password: storedPassword
      });
      setRememberMe(true); // Set checkbox to true if credentials are stored
    }
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleRememberMeChange = (e) => {
    setRememberMe(e.target.checked);
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Make an API call to login
      const response = await axios.post('https://localhost:7207/api/auth/login', formData);
      alert(response.data.message);

      if (response.data.success) {
        // If login is successful, redirect to the dashboard page
        navigate('http://localhost:5174/'); // Replace with the actual path to your dashboard page
      }

      if (rememberMe) {
        // Store email and password in localStorage if Remember Me is checked
        localStorage.setItem('email', formData.email);
        localStorage.setItem('password', formData.password);
      } else {
        // Remove credentials from localStorage if Remember Me is unchecked
        localStorage.removeItem('email');
        localStorage.removeItem('password');
      }

      setLoading(false);
    } catch (error) {
      console.error("There was an error!", error);
      setLoading(false);
      alert("Login Failed. Please check your credentials and try again.");
    }
  };

  // Handle "Forgot Password" click
  const handleForgotPassword = () => {
    alert("Please contact your admin for password reset.");
  };

  // Handle "Admin" click
  const handleContactAdmin = () => {
    alert("Please contact your admin for account creation.");
  };

  return (
    <div className="container-fluid position-relative d-flex p-0">
      {/* Spinner Start */}
      {loading && (
        <div
          id="spinner"
          className="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center"
        >
          <div
            className="spinner-border text-primary"
            style={{ width: "3rem", height: "3rem" }}
            role="status"
          >
            <span className="sr-only">Loading...</span>
          </div>
        </div>
      )}
      {/* Spinner End */}

      {/* Login Start */}
      <div className="container-fluid bg-dark">
        <div
          className="row h-100 align-items-center justify-content-center"
          style={{ minHeight: "100vh" }}
        >
          <div className="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
            <div className="bg-white rounded p-4 p-sm-5 my-4 mx-3">
              <div className="d-flex align-items-center justify-content-center mb-3">
                <h3 className="text-danger fw-bold">Promco 2.0</h3>
                <h3 className="text-dark fw-normal ms-2">Login</h3>
              </div>
              <form onSubmit={handleLogin}>
                <div className="form-floating mb-3">
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="form-control bg-dark text-light"
                    id="floatingInput"
                    placeholder="name@example.com"
                    required
                  />
                  <label htmlFor="floatingInput" className="text-light">Email address</label>
                </div>
                <div className="form-floating mb-4">
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className="form-control bg-dark text-light"
                    id="floatingPassword"
                    placeholder="Password"
                    required
                  />
                  <label htmlFor="floatingPassword" className="text-light">Password</label>
                </div>
                <div className="d-flex align-items-center justify-content-between mb-4">
                  <div className="form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="exampleCheck1"
                      checked={rememberMe}
                      onChange={handleRememberMeChange}
                      style={{ backgroundColor: 'black', borderColor: 'black' }} 
                    />
                    <label className="form-check-label text-dark" htmlFor="exampleCheck1">
                      Remember Me
                    </label>
                  </div>
                  <a href="#" className="text-danger" onClick={handleForgotPassword}>Forgot Password</a>
                </div>
                <button type="submit"
                  className="btn btn-dark py-3 w-100 mb-4"
                  style={{ color: 'white' }}
                >
                  Login
                </button>
              </form>
              <p className="text-center mb-0 text-dark">
                Don't have an Account? <Link to="#" className='text-danger' onClick={handleContactAdmin}>Admin</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
      {/* Login End */}
    </div>
  );
};

export default Login;
